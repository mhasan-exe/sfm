import 'package:cloud_firestore/cloud_firestore.dart';

import 'admin_config_service.dart';
import 'notification_service.dart';
import 'timetable_service.dart';
import 'fixture_service.dart';

class LeaveService {
  CollectionReference<Map<String, dynamic>> get _leaveRequests =>
      FirebaseFirestore.instance.collection('leave_requests');

  final AdminConfigService _adminConfig = AdminConfigService();

  /// Compares two Firestore values that should be Timestamps (handles
  /// null/missing gracefully so a doc with no value sorts last instead of
  /// throwing). Used to sort client-side and avoid needing a composite
  /// Firestore index for where()+orderBy() queries.
  int _compareTimestamps(dynamic a, dynamic b) {
    final da = a is Timestamp ? a.toDate() : DateTime.fromMillisecondsSinceEpoch(0);
    final db = b is Timestamp ? b.toDate() : DateTime.fromMillisecondsSinceEpoch(0);
    return da.compareTo(db);
  }

  // Submit a leave request
  Future<String> submitLeave({
    required String teacherId,
    required String teacherName,
    required DateTime startDate,
    required DateTime endDate,
    required String reason,
  }) async {
    if (endDate.isBefore(startDate)) {
      throw Exception('End date cannot be before start date');
    }

    // Admin-configurable cutoff:
    // - Reject same-day requests after cutoff time.
    // - Allow only startDate >= tomorrow when it is a same-day request.
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final tomorrow = today.add(const Duration(days: 1));

    final isSameDayRequest =
        DateTime(startDate.year, startDate.month, startDate.day) == today;

    // --- Anti-spam: block if a pending request already exists, or a
    // recent rejection is still inside its cooldown window. This applies
    // regardless of which dates are requested — one open conversation
    // about leave at a time per teacher. ---
    final existingSnapshot =
        await _leaveRequests.where('teacherId', isEqualTo: teacherId).get();

    DateTime? mostRecentRejectedAt;
    for (final doc in existingSnapshot.docs) {
      final data = doc.data();
      final status = data['status']?.toString();
      if (status == 'pending') {
        throw Exception(
            'You already have a pending leave request. Please wait for it to be reviewed before submitting another.');
      }
      if (status == 'rejected') {
        final rejectedAt = data['rejectedAt'];
        final dt = rejectedAt is Timestamp ? rejectedAt.toDate() : null;
        if (dt != null &&
            (mostRecentRejectedAt == null || dt.isAfter(mostRecentRejectedAt))) {
          mostRecentRejectedAt = dt;
        }
      }
    }

    if (mostRecentRejectedAt != null) {
      final cooldownHours = await _adminConfig.getRejectionCooldownHours();
      final cooldownEnds =
          mostRecentRejectedAt.add(Duration(hours: cooldownHours));
      if (now.isBefore(cooldownEnds)) {
        final remaining = cooldownEnds.difference(now);
        final hoursLeft = remaining.inHours;
        final minutesLeft = remaining.inMinutes % 60;
        throw Exception(
            'Your last leave request was rejected. Please wait ${hoursLeft}h ${minutesLeft}m before submitting another.');
      }
    }

    if (isSameDayRequest) {
      // Single unified cutoff governs leave/fixture-claim/fixture-exchange
      // alike — see AdminConfigService.isPastUnifiedCutoffNow.
      if (await _adminConfig.isPastUnifiedCutoffNow()) {
        throw Exception('Same-day leave requests are blocked after cutoff time');
      }

      // Before/at cutoff allowed, but spec requires: startDate == today only allowed before cutoff.
      // Otherwise, force startDate >= tomorrow.
      // (No extra check here because above covers the only forbidden condition.)
    } else {
      // If somehow caller tries startDate < today, reject as well.
      final startDay = DateTime(startDate.year, startDate.month, startDate.day);
      if (startDay.isBefore(today)) {
        throw Exception('Leave start date cannot be in the past');
      }
      // If startDate is today it is handled above.
      // startDate >= tomorrow is allowed.
      if (startDay.isBefore(tomorrow) && !isSameDayRequest) {
        throw Exception('Invalid leave start date');
      }
    }

    final docRef = await _leaveRequests.add({
      'teacherId': teacherId,
      'teacherName': teacherName,
      'startDate': Timestamp.fromDate(startDate),
      'endDate': Timestamp.fromDate(endDate),
      'reason': reason,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'approvedAt': null,
      'rejectedAt': null,
      'approvedBy': null,
      'rejectionReason': null,
    });

    // Real notification: tell every admin a new leave request is waiting.
    final dateLabel = endDate.difference(startDate).inDays == 0
        ? _formatDate(startDate)
        : '${_formatDate(startDate)} – ${_formatDate(endDate)}';
    await NotificationService().notifyAdmins(
      title: 'New leave request',
      body: '$teacherName requested leave for $dateLabel',
      action: 'leave_submitted',
      data: {'leaveRequestId': docRef.id, 'teacherId': teacherId},
    );

    return docRef.id;
  }

  String _formatDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// Returns true if the teacher already has an *approved* leave that overlaps
  /// the provided [startDate]..[endDate] (inclusive).
  Future<bool> hasApprovedLeaveOverlap({
    required String teacherId,
    required DateTime startDate,
    required DateTime endDate,
  }) async {
    if (endDate.isBefore(startDate)) return false;

    final snapshot = await _leaveRequests
        .where('teacherId', isEqualTo: teacherId)
        .where('status', isEqualTo: 'approved')
        .get();

    for (final doc in snapshot.docs) {
      final leave = doc.data();
      final approvedStart = (leave['startDate'] as Timestamp).toDate();
      final approvedEnd = (leave['endDate'] as Timestamp).toDate();

      // inclusive overlap
      final overlaps = !approvedEnd.isBefore(startDate) &&
          !approvedStart.isAfter(endDate);

      if (overlaps) return true;
    }

    return false;
  }

  // ---------------------------------------------------------------------
  // Approve a leave request.
  //
  // FIX (concurrency / "what if two admins approve at the same time?"):
  // the status flip from 'pending' -> 'approved' now happens inside a
  // Firestore transaction that re-reads the document and aborts if it's
  // no longer 'pending'. Two admins tapping "Approve" within the same
  // instant can therefore never both succeed — the loser gets a clean
  // "already handled" exception instead of silently re-running the
  // (expensive, side-effectful) slot-vacating + fixture-creation flow
  // twice, which used to risk duplicate fixtures.
  //
  // FIX (ghost duplicate writes / "what if internet disconnects during
  // approval?"): every exception/fixture doc this creates now has a
  // deterministic id (slotId+date), so retrying this entire call after a
  // dropped connection is always safe — nothing is ever duplicated.
  //
  // FIX (multiple sources of truth): this used to ALSO directly write into
  // `daily_timetables` with a second, separate, completely redundant pass
  // over every class right after already clearing the same teacher's
  // schedule via TimetableService — the exact "multiple sources of truth"
  // bug. There is now exactly one call that does this:
  // TimetableService.resyncTeacherLeaveExceptions.
  // ---------------------------------------------------------------------
  Future<void> approveLeave({
    required String leaveRequestId,
    required String adminId,
    String? adminComment,
  }) async {
    final leaveRef = _leaveRequests.doc(leaveRequestId);

    late String teacherId;
    late DateTime startDate;
    late DateTime endDate;

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final leaveDoc = await tx.get(leaveRef);
      if (!leaveDoc.exists) {
        throw Exception('Leave request not found');
      }
      final data = leaveDoc.data()!;
      final status = (data['status'] as String?) ?? 'pending';
      if (status != 'pending') {
        throw Exception(
            'This leave request was already $status by someone else.');
      }

      teacherId = (data['teacherId'] as String?) ?? '';
      if (teacherId.isEmpty) {
        throw Exception('Leave request missing teacherId');
      }
      startDate = (data['startDate'] as Timestamp).toDate();
      endDate = (data['endDate'] as Timestamp).toDate();
      if (endDate.isBefore(startDate)) {
        throw Exception('Invalid leave date range');
      }

      tx.update(leaveRef, {
        'status': 'approved',
        'approvedAt': FieldValue.serverTimestamp(),
        'approvedBy': adminId,
        'adminComment': adminComment,
      });
    });

    // From here on the approval itself is committed and final — everything
    // below is "apply the consequences of an approval that already
    // happened". Every write here is idempotent (deterministic doc ids),
    // so it's safe to surface failures instead of swallowing them: if this
    // throws, the leave IS approved (that part already committed above),
    // but the admin needs to know the schedule wasn't actually vacated so
    // they can fix the root cause and hit "Resync schedule" — silently
    // eating the error here is exactly how "leave approved but slots
    // never emptied, with no error anywhere" bugs happen. The most common
    // cause: a newly-added collection (`timetable_exceptions`) with no
    // Firestore security rule yet, so every write to it is silently
    // rejected as permission-denied unless you've already updated your
    // rules to allow it.
    List<Map<String, dynamic>> vacatedSlots;
    try {
      vacatedSlots = await TimetableService().resyncTeacherLeaveExceptions(teacherId);
    } catch (e) {
      throw Exception(
          'Leave was approved, but the schedule could not be synced (slots may still show the absent teacher): $e\n\nCheck that your Firestore security rules allow writes to the "timetable_exceptions" collection, then use "Resync schedule" for this teacher.');
    }

    try {
      if (vacatedSlots.isNotEmpty) {
        await FixtureService().createFixturesForSlots(uncoveredSlots: vacatedSlots);
      }
    } catch (_) {}

    // "What if someone exchanges a fixture and then gets leave approved?":
    // if this teacher had ALREADY claimed/been-assigned someone else's
    // fixture (agreed to cover a different absence) for a date that now
    // falls inside their own newly-approved leave, they can no longer show
    // up for that cover either — release it back to the marketplace
    // instead of silently leaving a fixture "covered" by someone who is
    // now also absent.
    try {
      await FixtureService().releaseFixturesForTeacherDuringLeave(
        teacherId: teacherId,
        startDate: startDate,
        endDate: endDate,
      );
    } catch (_) {}

    // Real notification: tell the teacher their leave was approved, and
    // exactly which classes/units were freed up so they can see at a
    // glance what's been affected.
    final dateLabel = endDate.difference(startDate).inDays == 0
        ? _formatDate(startDate)
        : '${_formatDate(startDate)} – ${_formatDate(endDate)}';
    final affectedSummary = vacatedSlots.isEmpty
        ? ''
        : ' ${vacatedSlots.length} class unit(s) (${vacatedSlots.map((s) => '${s['className']} U${s['unit']}').toSet().take(5).join(', ')}) have been opened up for cover.';
    await NotificationService().notifyTeacher(
      teacherId: teacherId,
      title: 'Leave approved',
      body: 'Your leave request for $dateLabel has been approved.$affectedSummary',
      type: NotificationType.leaveApproved,
      data: {'leaveRequestId': leaveRequestId},
    );
  }

  // Reject a leave request — also transactional with a status guard, so
  // two admins racing an approve vs. a reject on the same request can
  // never both win.
  Future<void> rejectLeave({
    required String leaveRequestId,
    required String adminId,
    required String reason,
  }) async {
    final leaveRef = _leaveRequests.doc(leaveRequestId);
    String teacherId = '';

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final leaveDoc = await tx.get(leaveRef);
      if (!leaveDoc.exists) {
        throw Exception('Leave request not found');
      }
      final data = leaveDoc.data()!;
      final status = (data['status'] as String?) ?? 'pending';
      if (status != 'pending') {
        throw Exception(
            'This leave request was already $status by someone else.');
      }
      teacherId = (data['teacherId'] as String?) ?? '';

      tx.update(leaveRef, {
        'status': 'rejected',
        'rejectedAt': FieldValue.serverTimestamp(),
        'approvedBy': adminId,
        'rejectionReason': reason,
      });
    });

    if (teacherId.isNotEmpty) {
      await NotificationService().notifyTeacher(
        teacherId: teacherId,
        title: 'Leave request declined',
        body: reason.isEmpty
            ? 'Your leave request was declined.'
            : 'Your leave request was declined: $reason',
        type: NotificationType.leaveRejected,
        data: {'leaveRequestId': leaveRequestId},
      );
    }
  }

  // Get all pending leave requests for admin review
  Stream<List<Map<String, dynamic>>> watchPendingLeaves() {
    return _leaveRequests
        .where('status', isEqualTo: 'pending')
        .snapshots()
        .map((snapshot) {
      final list = snapshot.docs.map((doc) {
        final data = doc.data();
        return {...data, 'id': doc.id};
      }).toList();
      list.sort((a, b) => _compareTimestamps(b['createdAt'], a['createdAt']));
      return list;
    });
  }

  // Get all approved leave requests
  Stream<List<Map<String, dynamic>>> watchApprovedLeaves() {
    return _leaveRequests
        .where('status', isEqualTo: 'approved')
        .snapshots()
        .map((snapshot) {
      final list = snapshot.docs.map((doc) {
        final data = doc.data();
        return {...data, 'id': doc.id};
      }).toList();
      list.sort((a, b) => _compareTimestamps(b['startDate'], a['startDate']));
      return list;
    });
  }

  // Get leave requests for a specific teacher
  Stream<List<Map<String, dynamic>>> watchTeacherLeaves(String teacherId) {
    return _leaveRequests
        .where('teacherId', isEqualTo: teacherId)
        .snapshots()
        .map((snapshot) {
      final list = snapshot.docs.map((doc) {
        final data = doc.data();
        return {...data, 'id': doc.id};
      }).toList();
      list.sort((a, b) => _compareTimestamps(b['createdAt'], a['createdAt']));
      return list;
    });
  }

  // Check if teacher has approved leave on specific date
  Future<bool> hasApprovedLeaveOnDate(
    String teacherId,
    DateTime date,
  ) async {
    final snapshot = await _leaveRequests
        .where('teacherId', isEqualTo: teacherId)
        .where('status', isEqualTo: 'approved')
        .get();

    for (final doc in snapshot.docs) {
      final leave = doc.data();
      final startDate = (leave['startDate'] as Timestamp).toDate();
      final endDate = (leave['endDate'] as Timestamp).toDate();

      // Check if date falls within the leave period
      if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
        return true;
      }
    }

    return false;
  }

  // Get overlapping leave requests for teachers (for conflict detection)
  Future<List<Map<String, dynamic>>> getOverlappingLeaves(
    DateTime startDate,
    DateTime endDate,
  ) async {
    final snapshot = await _leaveRequests
        .where('status', isEqualTo: 'approved')
        .get();

    final overlapping = <Map<String, dynamic>>[];

    for (final doc in snapshot.docs) {
      final leave = doc.data();
      final leaveStart = (leave['startDate'] as Timestamp).toDate();
      final leaveEnd = (leave['endDate'] as Timestamp).toDate();

      // Check if date ranges overlap
      if (leaveStart.isBefore(endDate) && leaveEnd.isAfter(startDate)) {
        overlapping.add({...leave, 'id': doc.id});
      }
    }

    return overlapping;
  }

  // Get leave statistics
  Future<Map<String, dynamic>> getLeaveStats(String teacherId) async {
    final snapshot = await _leaveRequests
        .where('teacherId', isEqualTo: teacherId)
        .where('status', isEqualTo: 'approved')
        .get();

    int totalDays = 0;
    int totalLeaves = 0;

    for (final doc in snapshot.docs) {
      final leave = doc.data();
      final startDate = (leave['startDate'] as Timestamp).toDate();
      final endDate = (leave['endDate'] as Timestamp).toDate();

      final days = endDate.difference(startDate).inDays + 1;
      totalDays += days;
      totalLeaves += 1;
    }

    return {
      'totalLeaves': totalLeaves,
      'totalDays': totalDays,
      'averageDaysPerLeave': totalLeaves > 0 ? totalDays / totalLeaves : 0,
    };
  }

  // Cancel a pending leave request — also transactional, so a request
  // can't be cancelled in the same instant it's being approved/rejected by
  // an admin (whichever transaction commits first wins; the other sees a
  // status that's no longer 'pending' and fails cleanly).
  Future<void> cancelLeave({required String leaveRequestId}) async {
    final leaveRef = _leaveRequests.doc(leaveRequestId);

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final leaveDoc = await tx.get(leaveRef);
      if (!leaveDoc.exists) {
        throw Exception('Leave request not found');
      }
      final leave = leaveDoc.data()!;
      if (leave['status'] != 'pending') {
        throw Exception('Only pending leaves can be cancelled');
      }
      tx.update(leaveRef, {
        'status': 'cancelled',
        'cancelledAt': FieldValue.serverTimestamp(),
      });
    });
  }
}
